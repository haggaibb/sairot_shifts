// Copyright 2019 Aleksander Woźniak
// SPDX-License-Identifier: Apache-2.0

import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
import 'package:table_calendar/table_calendar.dart';


/// Example Instructor class.
class Instructor {
  final String armyId;
  final String firstName;
  final String lastName;
  final String mobile;
  final String email;

  const Instructor(this.armyId,this.firstName,this.lastName,this.mobile,this.email);

  @override
  String toString() => armyId;
}

class Request {
  final String armyId;
  final String fullName;
  final DateTime requestInit;
  final String type;
  final DateTime giveDay;
  final DateTime? takeDay;
  final String? requestId;

  const Request(this.armyId,this.fullName,this.requestInit,this.type,this.giveDay,this.takeDay,this.requestId);

  Map toJson() => {
    'army_id': armyId,
    'full_name': fullName,
    'requestInit' : requestInit,
    'type' : type,
    'give_day' : giveDay,
    'take_day' : takeDay,
    'requestId' : requestId
  };

  @override
  String toString() => armyId;
}


List<Instructor> InstructorData=[];



getDataOld() async {
  var db = FirebaseFirestore.instance;
  CollectionReference eventDaysRef = db.collection('Events/October 2022/instructors');
  QuerySnapshot days = await eventDaysRef.get();
  List<Instructor> tempInstructorData=[];
  days.docs.forEach((element){
    var instructors = element.data() as Map<String, dynamic>;
    //print(instructors);
    tempInstructorData.add(Instructor(element.id, instructors['first_name'],  instructors['last_name']??'NA',  instructors['mobile']??'NA', instructors['email']??'NA'));
  });
  InstructorData = tempInstructorData;
  print('got data');
}

getInstructorData(String instructorId, List<Instructor> instructorsList) {
  bool found = false;
  int index = 0;
  var instructorData;
  while (!found && index <instructorsList.length) {
    if (instructorsList[index].armyId==instructorId) {
      found=true;
      instructorData = {
        'armyId' :  instructorsList[index].armyId,
        'firstName' : instructorsList[index].firstName,
        'lastName' : instructorsList[index].lastName,
        'mobile' : instructorsList[index].mobile,
        'email' : instructorsList[index].email,
      };
    } else {
      index++;
    }
  }
  if (!found) {
    instructorData = {
    'armyId' :  '--',
    'firstName' :  '--',
    'lastName' :  '--',
    'mobile' :  '--'
  };
  }
  return instructorData;
}

toDateKey(DateTime selectedDay) {
  String dateKey = "${selectedDay.day.toString().padLeft(2,'0')}-${selectedDay.month.toString().padLeft(2,'0')}-${selectedDay.year.toString()}";
  return dateKey;
}

int getHashCode(DateTime key) {
  return key.day * 1000000 + key.month * 10000 + key.year;
}

