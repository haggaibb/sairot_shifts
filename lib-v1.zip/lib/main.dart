import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/date_symbol_data_local.dart';
import './utils.dart';
import 'package:shifts/pref_date_picker.dart';
import 'package:get/get.dart';
import 'exchange.dart';
import 'shifts_table_view.dart';
import 'package:url_launcher/url_launcher.dart';
import 'contacts_list.dart';

void main() async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  initializeDateFormatting().then((_) => runApp(
        MaterialApp(
          home: Directionality(
            // add this
            textDirection: TextDirection.rtl, // set this property
            child: DefaultTabController(length: 3, child: Home()),
          ),
        ),
      ));
}

class Controller extends GetxController {
  var eventName = '';
  var db = FirebaseFirestore.instance;
  RxList<Instructor> eventInstructors = RxList<Instructor>();

  RxList<Instructor> selectedDayInstructors = RxList<Instructor>();
  List eventDays = [].obs;
  List miluimEmails = [].obs;
  List instrctorsPerDay = [].obs;
  DateTime? _selectedDay = DateTime.now();
 // Rx<DateTime> _focusedDay = DateTime.utc(2023, 1, 4).obs;
  Rx<DateTime> _focusedDay = DateTime.now().obs;
  Rx<DateTime> startDate = DateTime.now().obs;
  Rx<DateTime> endDate = DateTime.now().obs;
  RxBool loading = true.obs;
  RxList daysForInstructor = [].obs;
  RxInt maxInstructorsPerDay = 0.obs;
  Rx<DateTime> editDaysOffEndDate = DateTime.now().obs;

  @override
  onInit() async {
    await loadEventMetadata();
    await loadEventInstructors();
    await loadEventDays();
    await loadSelectedDayInstructors(_focusedDay.value);
    loading.value = false;
    update();
  }

  void addInstructor(String instructorId, var instructorData) {
    eventInstructors.add(
      Instructor(
        instructorId,
        instructorData['first_name'] ?? 'NA',
        instructorData['last_name'] ?? 'NA',
        instructorData['mobile'] ?? 'NA',
        instructorData['email'] ?? 'NA',
      ),
    );
  }

  removeInstructorFromDay(String instructorId, DateTime selectedDay) async {
    String dateKey =
        "${selectedDay.day.toString().padLeft(2, '0')}-${selectedDay.month.toString().padLeft(2, '0')}-${selectedDay.year.toString()}";
    DocumentReference daysRef = db.collection('Events/' + eventName + '/days').doc(dateKey);
    await daysRef.update({
      'instructors' : FieldValue.arrayRemove([instructorId])
    });
    await daysRef.update({
     'instructors': FieldValue.arrayUnion(["0"])
    });
  }

  loadDaysForInstructor(String instructorId) async {
    daysForInstructor.value = [];
    CollectionReference eventDaysRef =
        db.collection('Events/' + eventName + '/days');
    QuerySnapshot eventDaysQuery = await eventDaysRef.get();
    eventDaysQuery.docs.forEach((day) {
      var dayData = day.data() as Map<String, dynamic>;
      List instructorList = dayData['instructors'];
      if (instructorList.contains(instructorId.trim())) daysForInstructor.add(day.id);
    });
    update();
    return daysForInstructor;
  }

  loadEventDays() async {
    CollectionReference eventDaysRef =
        db.collection('Events/' + eventName + '/days');
    QuerySnapshot eventDaysQuery = await eventDaysRef.get();
    eventDays = [];
    eventDaysQuery.docs.forEach((element) {
      eventDays.add(element.id);
      var dayData = element.data() as Map<String, dynamic>;
      var dayWithInstructors = [];
      dayData['instructors'].forEach((instructor) {
        dayWithInstructors.add(getInstructorData(instructor, eventInstructors));
      });
      instrctorsPerDay.add(dayWithInstructors);
    });
  }

  loadEventMetadata() async {
    DocumentReference eventConfigRef = db.doc('Events/config');
    DocumentSnapshot eventConfigQuery = await eventConfigRef.get();
    var eventConfig = eventConfigQuery.data() as Map<String, dynamic>;
    eventName = eventConfig['current_event'];
    miluimEmails = eventConfig['miluim_emails'];
    DocumentReference eventMetadataRef = db.doc('Events/' + eventName + '');
    DocumentSnapshot eventMetadataQuery = await eventMetadataRef.get();
    var eventMetadata = eventMetadataQuery.data() as Map<String, dynamic>;
    Timestamp timestampStart = eventMetadata['start_date'];
    startDate.value = timestampStart.toDate();
    Timestamp timestampEnd = eventMetadata['end_date'];
    endDate.value = timestampEnd.toDate();
    _focusedDay.value = DateTime.now();
    _focusedDay.value = DateTime.utc(2023, 1, 4); // debug!!!
    _selectedDay =  _focusedDay.value;
    maxInstructorsPerDay.value = eventMetadata['instructors_per_day'];
    Timestamp timestampDaysOffEndDate = eventMetadata['days_off_end_date'];
    editDaysOffEndDate.value = timestampDaysOffEndDate.toDate();
    update();
  }

  loadEventInstructors() async {
    CollectionReference eventInstructorsRef =
        db.collection('Events/' + eventName + '/instructors');
    QuerySnapshot eventInstructorsQuery = await eventInstructorsRef.get();
    var eventInstructorsList = eventInstructorsQuery.docs;
    eventInstructorsList.forEach((element) {
      var instructorData = element.data() as Map<String, dynamic>;
      addInstructor(element.id, instructorData);
    });
  }

  loadSelectedDayInstructors(DateTime selectedDay) async {
    if (selectedDay.weekday==DateTime.saturday || selectedDay.weekday==DateTime.friday) return;
    String dateKey =
        "${selectedDay.day.toString().padLeft(2, '0')}-${selectedDay.month.toString().padLeft(2, '0')}-${selectedDay.year.toString()}";
    print('Events/' + eventName + '/days');
    print(dateKey);
    DocumentReference eventDaysRef =
        db.collection('Events/' + eventName + '/days').doc(dateKey);
    DocumentSnapshot daySnap = await eventDaysRef.get();
    print(daySnap.data());
    selectedDayInstructors.clear();
    var dayData = daySnap.data() as Map<String, dynamic>;
    List selectedDayInstructorsId = dayData['instructors'];
    int index = 0;
    while (index < eventInstructors.length) {
      if (selectedDayInstructorsId.contains(eventInstructors[index].armyId)) {
        selectedDayInstructors.add(eventInstructors[index]);
      }
      index++;
    }
    selectedDayInstructors.sort((a, b) => a.firstName.toString().compareTo(b.firstName.toString()));
    _selectedDay = selectedDay;
    _focusedDay.value = selectedDay;
    update();
  }

  sendMyDaysMail(instructorId, days) async {
    var instructorData = getInstructorData(instructorId, eventInstructors);
    print(days);
    print(instructorData['email']);
    var subject = "-" + "המשמרות שלי בימי סיירות " + "-";
    var text = " רשימת הימים להיתיצבות " + "\n";
    text = text + "\n" + days.toString();
    var lines = '<p style="text-align:center">&nbsp;</p>';
    lines +=
        '<table align="center" border="3" cellpadding="20" cellspacing="1" dir="rtl" style="width:500px">';
    lines += '	<thead>';
    lines += '		<tr>';
    lines +=
        '			<center><img src="https://upload.wikimedia.org/wikipedia/he/7/72/%D7%9C%D7%95%D7%92%D7%95_%D7%A2%D7%9E%D7%95%D7%AA%D7%AA_%D7%94%D7%A2%D7%98%D7%9C%D7%A3.png" alt="Atalef" width="150"></center>';
    lines += '		</tr>';
    lines += '	</thead>';
    lines += '	<tbody>';
    lines += '		<tr>';
    lines +=
        '			<th scope="col" style="width:374px"><span style="font-size:20px"><span style="color:#e74c3c"> רשימת הימים שלך להתייצבות  </span></span</th>';
    lines += '		</tr>';
    for (var day in days) {
      lines += '		<tr>';
      lines += '			<td style="text-align:center" style="width:374px">' +
          day.toString() +
          '</td>';
      lines += '		</tr>';
    }
    lines += '		<tr>';
    lines +=
        '			<td style="text-align:center"><a href="https://yemey-siarot.web.app/">לחץ לאפליקציה</a></td>';
    lines += '		</tr>';
    lines += '	</tbody>';
    lines += '</table>';
    lines += '<p style="text-align:right">&nbsp;</p>';
    await db.collection('mail').add({
      'to': instructorData['email'],
      'message': {'subject': subject, 'text': text, 'html': lines}
    });
  }

  sendMiluimDayReportMail(List<Instructor> instructorsList,String dateKey) async {
    var subject = "-" + " דוח יומי מילואים " + "-";
    var text = " רשימת המדריכים היומית " + "\n";
    text = text + "\n" + instructorsList.toString();
    var lines = '<p style="text-align:center">&nbsp;</p>';
    lines +=
    '<table align="center" border="3" cellpadding="20" cellspacing="1" dir="rtl" style="width:500px">';
    lines += '	<thead>';
    lines += '		<tr>';
    lines +=
    '			<center><img src="https://upload.wikimedia.org/wikipedia/he/7/72/%D7%9C%D7%95%D7%92%D7%95_%D7%A2%D7%9E%D7%95%D7%AA%D7%AA_%D7%94%D7%A2%D7%98%D7%9C%D7%A3.png" alt="Atalef" width="150"></center>';
    lines += '		</tr>';
    lines += '	</thead>';
    lines += '	<tbody>';
    lines += '		<tr>';
    lines +=
    '</th><th scope="col" style="width:374px"><span style="font-size:20px"><span style="color:#e74c3c">'+ dateKey +' רשימת המדריכים היומית  </span></span</th>';
    lines += '		</tr>';
    for (var instructor in instructorsList) {
      lines += '		<tr>';
      lines += '			<td style="text-align:center" style="width:374px">' +
          instructor.firstName + '  ' + instructor.lastName +
          '</td>';
      lines += '		</tr>';
    }
    lines += '		<tr>';
    lines +=
    '			<td style="text-align:center"><a href="https://yemey-siarot.web.app/">לחץ לאפליקציה</a></td>';
    lines += '		</tr>';
    lines += '	</tbody>';
    lines += '</table>';
    lines += '<p style="text-align:right">&nbsp;</p>';
    await db.collection('mail').add({
      'to': miluimEmails,
      'message': {'subject': subject, 'text': text, 'html': lines}
    });
  }

}

class Home extends StatelessWidget {
  final controller = Get.put(Controller());
  CalendarFormat _calendarFormat = CalendarFormat.week;
  List<Instructor> _getInstructorsForDay(DateTime selectedDay) {
    return controller.selectedDayInstructors;
  }

  Future<List> _getDaysForInstructor(String instructorId) async {
    return await controller.loadDaysForInstructor(instructorId);
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) async {
    await controller.loadSelectedDayInstructors(selectedDay);
  }

  @override
  Widget build(BuildContext context) {
    final Controller controller = Get.put(Controller());
    final _formKey = GlobalKey<FormState>();
    final instructorIdController = TextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Column(
            children: [
              SizedBox(
                  width: 70, child: Image.network('assets/images/logo.png')),
              const Text(
                'ימי סיירות',
                style: TextStyle(fontSize: 20),
              ),
            ],
          ),
        ),
        bottom: const TabBar(
          tabs: [
            Tab(icon: Icon(Icons.calendar_month_rounded)),
            Tab(icon: Icon(Icons.list_outlined)),
            Tab(icon: Icon(Icons.person)),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text('תפריט ראשי'),
            ),
            ListTile(
              leading: const Icon(
                Icons.date_range,
              ),
              title: const Text('לו״ז'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.date_range_rounded,
              ),
              title: const Text('הזן  אילוצים'),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => Obx(() => PrefDatePicker(
                        startDate: controller.startDate.value,
                        endDate: controller.endDate.value)),
                  ),
                );
              },
            ),
            Obx(() => !controller.loading.value
                ? ListTile(
                    leading: const Icon(
                      Icons.edit,
                    ),
                    title: const Text('החלפות  ומסירות'),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (context) => Directionality(
                                  // add this
                                  textDirection:
                                      TextDirection.rtl, // set this property
                                  child: ExchangeHome(),
                                )),
                      );
                    },
                  )
                : Text('')),
            Obx(() => !controller.loading.value
                ? ListTile(
                    leading: const Icon(
                      Icons.contacts_outlined,
                    ),
                    title: const Text('דף קשר'),
                    onTap: () {
                      List allInstructors = controller.eventInstructors;
                      allInstructors.sort((a, b) {
                        return a.firstName
                            .toString()
                            .compareTo(b.firstName.toString());
                      });
                      Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (context) => Directionality(
                                  // add this
                                  textDirection:
                                      TextDirection.rtl, // set this property
                                  child: ContactsListPage(
                                      eventInstructors:
                                          controller.eventInstructors),
                                )),
                      );
                    },
                  )
                : Text('')),
          ],
        ),
      ),
      body: Obx(() => !controller.loading.value
          ? TabBarView(children: [
              Center(
                child: Column(
                  //mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    //Container(child: Image.asset('images/logo.png'), width: 75),
                    const SizedBox(height: 20),
                    Obx(() => SizedBox(
                          height: 150,
                          width: 400,
                          child: TableCalendar(
                            locale: 'he_HE',
                            headerStyle: const HeaderStyle(
                                titleCentered: true,
                                formatButtonVisible: false),
                            weekendDays: [DateTime.friday, DateTime.saturday],
                            firstDay: controller.startDate.value,
                            lastDay: controller.endDate.value,
                            focusedDay: controller._focusedDay.value,
                            calendarFormat: _calendarFormat,
                            selectedDayPredicate: (day) =>
                                isSameDay(controller._selectedDay, day),
                            calendarStyle: const CalendarStyle(
                              defaultTextStyle: TextStyle(
                                  color: Colors.blueAccent,
                                  fontWeight: FontWeight.bold),
                              weekendTextStyle: TextStyle(color: Colors.red),
                              isTodayHighlighted: false,
                              outsideDaysVisible: false,
                              markersMaxCount: 0,
                            ),
                            eventLoader: _getInstructorsForDay,
                            onDaySelected: _onDaySelected,
                            onDayLongPressed: (selected,focused)  async {
                              await controller.loadSelectedDayInstructors(selected);
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => DayReportPage(eventInstructors: controller.selectedDayInstructors ,selectedDay: selected),
                                ),
                              );
                              //print(controller.selectedDayInstructors.toString());
                            },
                          ),
                        )),
                    Expanded(
                      child: Obx(() => ListView.builder(
                          itemCount: controller.selectedDayInstructors.length,
                          itemBuilder: (context, index) {
                            final instructor =
                                controller.selectedDayInstructors[index];
                            final Uri telLaunchUri = Uri(
                              scheme: 'tel',
                              path: instructor.mobile,
                            );
                            final Uri smsLaunchUri = Uri(
                              scheme: 'sms',
                              path: instructor.mobile,
                              queryParameters: <String, String>{},
                            );
                            return Card(
                                child: ExpansionTile(
                              expandedAlignment: Alignment.topRight,
                              title: Text(
                                  '${index + 1}. ${instructor.firstName} ${instructor.lastName}'),
                              children: [
                                Row(
                                  children: [
                                    Text(' נייד ${instructor.mobile} '),
                                    ElevatedButton(
                                      style: const ButtonStyle(
                                        visualDensity: VisualDensity(
                                            horizontal:
                                                VisualDensity.minimumDensity,
                                            vertical:
                                                VisualDensity.minimumDensity),
                                      ),
                                      onPressed: () async =>
                                          {await launchUrl(telLaunchUri)},
                                      child: const Text('חייג'),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    ElevatedButton(
                                      style: const ButtonStyle(
                                        visualDensity: VisualDensity(
                                            horizontal:
                                                VisualDensity.minimumDensity,
                                            vertical:
                                                VisualDensity.minimumDensity),
                                      ),
                                      onPressed: () async =>
                                          {await launchUrl(smsLaunchUri)},
                                      child: const Text('הודעה'),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                )
                                //Row(children: [Text(' מ.א. ${instructor.armyId}'),],)
                              ],
                            ));
                          })),
                    ),
                  ],
                ),
              ),
              Obx(() => Center(
                    child: ShiftsTableView(
                      instructorsPerDayList: controller.instrctorsPerDay,
                      daysList: controller.eventDays,
                      maxInstructorsPerDay:
                          controller.maxInstructorsPerDay.value,
                    ),
                  )),
              Center(
                child: Column(
                  children: [
                    //Container(child: Image.asset('images/logo.png'), width: 75),
                    SizedBox(height: 30),
                    SizedBox(
                      width: 200,
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('מיין לפי תעודת  זהות'),
                            TextFormField(
                              controller: instructorIdController,
                              // The validator receives the text that the user has entered.
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  'לא הוזן כלום!';
                                }
                                return null;
                              },
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 16.0),
                              child: ElevatedButton(
                                onPressed: () async {
                                  //instructorIdController.text='4687061'; // for debug
                                  // Validate returns true if the form is valid, or false otherwise.
                                  if (_formKey.currentState!.validate()) {
                                    // If the form is valid, display a snackbar. In the real world,
                                    // you'd often call a server or save the information in a database.
                                    print(instructorIdController.text);

                                    var gotData = await _getDaysForInstructor(
                                        instructorIdController.text);
                                    print(instructorIdController.text);
                                    print(gotData.length);
                                    if (gotData.length == 0) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        const SnackBar(
                                            content: Text('לא נמצאו ימים!!!')),
                                      );
                                    }
                                  }
                                },
                                child: const Text('חפש'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    controller.daysForInstructor.length > 0
                        ? Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: ElevatedButton(
                              onPressed: () async {
                                controller.sendMyDaysMail(
                                    instructorIdController.text,
                                    controller.daysForInstructor);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                      content: Text(
                                    'המידע נשלח אליך למייל האישי',
                                    style: TextStyle(color: Colors.white),
                                  )),
                                );
                              },
                              child: Container(
                                width: 180,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: const [
                                    Icon(Icons.mail_outline_sharp),
                                    Text('שלח את המידע למייל שלי'),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : const SizedBox(
                            height: 10,
                          ),
                    Expanded(
                        child: Obx(() => SizedBox(
                              width: 150,
                              child: ListView.builder(
                                  itemCount:
                                      controller.daysForInstructor.length,
                                  itemBuilder: (context, index) {
                                    return Card(
                                      color: Colors.lightGreenAccent,
                                      child: Text(
                                        controller.daysForInstructor[index],
                                        style: TextStyle(fontSize: 20),
                                        textAlign: TextAlign.center,
                                      ),
                                    );
                                  }),
                            ))),
                  ],
                ),
              ),
            ])
          : const LoadingLogo()),
    );
  }
}

class LoadingLogo extends StatelessWidget {
  const LoadingLogo({super.key});

  // This widget is the home page of your application.

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(
          height: 200,
        ),
        Center(
            child: Container(
                width: 350,
                child: Image.network('assets/images/logo.png'))),
        Center(
            child: Container(
                child: const Text(
          'טוען נתונים',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ))),
      ],
    );
  }
}

class DayReportPage extends StatelessWidget {
  final controller = Get.put(Controller());
  final List eventInstructors;
  final DateTime selectedDay;
  DayReportPage({super.key, List? eventInstructors, DateTime? selectedDay }):eventInstructors = eventInstructors ?? [], selectedDay = selectedDay ?? DateTime.now();
  @override

  @override
  Widget build(BuildContext context) {
    String dateKey =
        "${selectedDay.day.toString().padLeft(2, '0')}-${selectedDay.month.toString().padLeft(2, '0')}";
    return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: Text(' דוח יומי משרד מילואים ל $dateKey', style: TextStyle(fontSize: 18),),
          ),
          body: Center(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child:  ElevatedButton(
                    onPressed: () async {
                      await controller.sendMiluimDayReportMail(
                          controller.eventInstructors, dateKey);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text(
                              'המידע נשלח אליך למייל האישי',
                              style: TextStyle(color: Colors.white),
                            )),
                      );
                    },
                    child: Container(
                      width: 180,
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceEvenly,
                        children: const [
                          Icon(Icons.mail_outline_sharp),
                          Text('שלח את המידע למייל'),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    width: 150,
                    child: Center(
                      child: ListView.builder(
                          itemCount: eventInstructors.length,
                          itemBuilder: (context, index) {
                            final instructor = eventInstructors[index];
                            return GestureDetector(
                              onLongPress: () async {
                                print('long press');
                                bool? res = await showDialog<bool>(
                                    context: context,
                                    builder: (BuildContext context) => YesNoDialog()
                                );
                                if (res??false) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                        content: Text(
                                          'מסיר מדריך מהרשימה',
                                          style: TextStyle(color: Colors.white),
                                        )),
                                  );
                                  await controller.removeInstructorFromDay(instructor.armyId,selectedDay);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                        content: Text(
                                          'המדריך הוסר',
                                          style: TextStyle(color: Colors.white),
                                        )),
                                  );
                                }
                              },
                              child: Card(
                                  child: Text(
                                    '${index + 1}. ${instructor.firstName} ${instructor.lastName}',
                                    style: TextStyle(fontWeight: FontWeight.bold,fontSize: 12),)
                              ),
                            );
                          }),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}


class YesNoDialog extends StatelessWidget {
  const YesNoDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('האם אתה בטוח'),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(context, true),
          child: const Text('כן'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('לא'),
        ),
      ],
    );
  }
}
