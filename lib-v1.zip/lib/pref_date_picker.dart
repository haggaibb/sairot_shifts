import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:table_calendar/table_calendar.dart';
import './utils.dart';
import 'dart:collection';

class PrefDatePicker extends StatefulWidget {
  final DateTime startDate;
  final DateTime endDate;

  PrefDatePicker({Key? key, DateTime? startDate, DateTime? endDate})
      : this.startDate = startDate ?? DateTime.now(),
        this.endDate = endDate ?? DateTime.now();
  @override
  State<PrefDatePicker> createState() => _PrefDatePickerState();
}

class _PrefDatePickerState extends State<PrefDatePicker> {
  var db = FirebaseFirestore.instance;
  late final ValueNotifier<List<Instructor>> _selectedInstructors;
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime? _focusedDay;
  final Set<DateTime> _selectedDays = LinkedHashSet<DateTime>(
    equals: isSameDay,
    hashCode: getHashCode,
  );
  var eventMetadata = null;
  var eventName = '';
  var eventInstructors = [];
  var editDaysOffEndDate = DateTime.now();
  var isLoading = true;
  loadEventMetadata() async {
    DocumentReference eventConfigRef = db.doc('Events/config');
    DocumentSnapshot eventConfigQuery = await eventConfigRef.get();
    var eventConfig = eventConfigQuery.data() as Map<String, dynamic>;
    eventName = eventConfig['current_event'];
    DocumentReference eventMetadataRef = db.doc('Events/$eventName');
    DocumentSnapshot eventMetadataQuery = await eventMetadataRef.get();
    eventMetadata = eventMetadataQuery.data() as Map<String, dynamic>;
    CollectionReference eventInstructorsRef =
        db.collection('Events/$eventName/instructors');
    QuerySnapshot eventInstructorsQuery = await eventInstructorsRef.get();
    var eventInstructorsList = eventInstructorsQuery.docs;
    eventInstructorsList.forEach((element) {
      eventInstructors.add(element.id);
    });
    Timestamp timestampDaysOffEndDate = eventMetadata['days_off_end_date'];
    setState(() {
      editDaysOffEndDate = timestampDaysOffEndDate.toDate();
      isLoading = false;
    });
  }

  Future<void> addDaysOffRequest(instructorId) async {
    DocumentReference initialDaysOffRequest = FirebaseFirestore.instance
        .collection('/Events/$eventName/instructors/')
        .doc(instructorId);
    initialDaysOffRequest.update({
      'days_off': _selectedDays,
    }).then((value) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('הנתונים הוזנו בהצלחה...')));
      Navigator.pop(context);
      Navigator.pop(context);
    }).catchError((error) => ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('הזנת הנתונים נכשלה !!!'))));
  }

  isValidId(id) {
    if (eventInstructors.contains(id)) {
      return true;
    } else {
      return false;
    }
  }

  @override
  void initState() {
    _getThingsOnStartup().then((value) {
      print('loaded Metadata');
    });
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future _getThingsOnStartup() async {
    await loadEventMetadata();
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    setState(() {
      _focusedDay = focusedDay;
      // Update values in a Set
      if (_selectedDays.contains(selectedDay)) {
        _selectedDays.remove(selectedDay);
      } else {
        _selectedDays.add(selectedDay);
      }
    });
    //print(_selectedDays);
  }

  @override
  Widget build(BuildContext context) {
    CollectionReference dates = FirebaseFirestore.instance.collection('Dates');
    final formKey = GlobalKey<FormState>();
    final instructorIdController = TextEditingController();
    final DateTime now = DateTime.now();
    //if (isLoading) return const Center(child: Text('טוען'));
    if (now.compareTo(editDaysOffEndDate) > 0) {
      return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            appBar: AppBar(
              title: Text('בחירת ימי חופש'),
            ),
            body: Center(
              child: Column(
                children: [
                  const SizedBox(height: 200),
                  const Text('עבר הזמן להזנת ימי חופש',
                      style: TextStyle(fontSize: 24)),
                  const SizedBox(height: 250),
                  ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text('חזרה'))
                ],
              ),
            ),
          ));
    } else {
      return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('בחירת ימי חופש'),
            ),
            body: Center(
              child: Column(
                //mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const SizedBox(
                    height: 100,
                    child: Center(
                        child: Text(
                      'נא סמן את ימי החופש הנדרשים',
                      style: TextStyle(fontSize: 24),
                    )),
                  ), //Title
                  TableCalendar(
                    locale: 'he_HE',
                    weekendDays: const [DateTime.friday, DateTime.saturday],
                    headerStyle: const HeaderStyle(
                        titleCentered: true, formatButtonVisible: false),
                    firstDay: widget.startDate,
                    lastDay: widget.endDate,
                    focusedDay: _focusedDay ?? widget.startDate,
                    calendarFormat: _calendarFormat,
                    onFormatChanged: (format) {
                      if (_calendarFormat != format) {
                        setState(() {
                          _calendarFormat = format;
                        });
                      }
                    },
                    selectedDayPredicate: (day) {
                      // Use values from Set to mark multiple days as selected
                      return _selectedDays.contains(day);
                    },
                    calendarStyle: const CalendarStyle(
                      defaultTextStyle: TextStyle(
                          color: Colors.blueAccent,
                          fontWeight: FontWeight.bold),
                      weekendTextStyle: TextStyle(color: Colors.red),
                      isTodayHighlighted: false,
                      outsideDaysVisible: false,
                      markersMaxCount: 0,
                    ),
                    //eventLoader: _updateDaysPicked,
                    onDaySelected: _onDaySelected,
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: 150,
                    child: Form(
                      key: formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('הזן מספר אישי'),
                          TextFormField(
                            controller: instructorIdController,
                            // The validator receives the text that the user has entered.
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'לא הוזן כלום!';
                              } else if (!isValidId(value)) {
                                return 'מספר אישי לא קיים במערכת!';
                              }
                              return null;
                            },
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 16.0),
                            child: ElevatedButton(
                              onPressed: () async {
                                // Validate returns true if the form is valid, or false otherwise.
                                if (formKey.currentState!.validate()) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                        content: Text('מזין נתונים...')),
                                  );
                                  await addDaysOffRequest(
                                      instructorIdController.text);
                                }
                              },
                              child: const Text('עדכן'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ));
    }
  }
}
